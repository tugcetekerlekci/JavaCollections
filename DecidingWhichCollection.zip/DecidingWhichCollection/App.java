package DecidingWhichCollection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class App {
	
	
	public static void main(String[] args)
	{
		
		///////////LISTS ////////////////
		/* Store list of objects
		 * Duplicates are allowed
		 * Elements are indexed by integer
		 * Checking particular item is slow. 
		 * Looking an item up is fast
		 * Iterating thru list is relatively fast
		 * You can sort the list if you want to. 
		 * */
		
		//if you only want to remove or add items at the end of the list, use ArrayList. 
		List<String> list1 =new ArrayList<String>();
		
		//removing or adding somewhere in the list : 
		
		List<String> list2 = new LinkedList<String>();
		
		///////////SET ////////////////
		//store unique values
		//greate for removing duplicates.
		//Not indexed unlike lists. 
		//very fast to check of you're searching particular object. 
		//if you want to add objeccts you created your class, you must implement hshcode, equals.
		
		//order is NOT important : 
		Set<String> set1 = new HashSet<String>();
		
		//order is important, elemtents should remain in order where they're added.

		Set<String> set2 = new LinkedHashSet();
		
		//natural order is important : 
		//must implement Comparable fir Custom types. ... 
		Set<String> set3 = new TreeSet();
		
		
		
		///////////MAP ////////////////
		
		//key value pairs
		//look up table
		//retrieving a value by key is fast
		//iterating over map is slow
		//if you want to use your own objects, use hashCode and equals. 
		
		//Keys not in any particular order 
		Map<String,String> map2 = new HashMap<String,String>();
		
		//keys in natural order
		//must implement Comparable fir Custom types. ... 
		Map<String,String> map3 = new TreeMap<String,String>();
		
		//key remains in order added
		Map<String,String> map4 = new LinkedHashMap<String,String>();
		
		
		
		
		
	}

}
