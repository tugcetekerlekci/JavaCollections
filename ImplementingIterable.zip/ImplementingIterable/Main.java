package ImplementingIterable;

public class Main {
	
	public static void main(String[] args)
	{
		UrlLibrary urlLibrary = new UrlLibrary();
		
		//for is calling next as long as hasNext returns true. 
		for(String html: urlLibrary)
		{
			System.out.println(html.length());
			System.out.println(html);
		}
		
		
		
	}

}
